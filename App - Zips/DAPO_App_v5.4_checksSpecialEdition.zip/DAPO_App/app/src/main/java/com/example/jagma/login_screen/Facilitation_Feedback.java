package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;

public class Facilitation_Feedback extends AppCompatActivity {

    EditText d_f_a1;
    Spinner d_f_a2,d_f_a2_1,d_f_a2_2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facilitation__feedback);

        d_f_a1 = findViewById(R.id.d_f_a1);
        d_f_a2 = findViewById(R.id.d_f_a2);
        d_f_a2_1=findViewById(R.id.d_f_a2_1);
        d_f_a2_2=findViewById(R.id.d_f_a2_2); // Declaration



    }

    public void Proceed(View view) {
        if (d_f_a1 == null || d_f_a2.getSelectedItem().toString().equals("- Choose Location -") || d_f_a2_1.getSelectedItem().toString().equals("- Choose Category -")||
                d_f_a2_2.getSelectedItem().toString().equals("- Choose Centre -"))  {
            Toast.makeText(getApplicationContext(), "Fill at least one field", Toast.LENGTH_LONG).show();
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.dialog_proceed_head))
                    .setCancelable(false)
                    .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(Facilitation_Feedback.this,Submit_screen.class);
                        startActivityForResult(i,2);
                        finish();*/

                            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                            if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {

                                String Victims_Linked_To_Centres = d_f_a1.getText().toString();
                                String Contacted_Centre_Location = d_f_a2.getSelectedItem().toString();
                                String Contacted_Centre_Category = d_f_a2_1.getSelectedItem().toString();
                                String Centre_Contacted = d_f_a2_2.getSelectedItem().toString();


                                String type = "deaddiction facilitation";
                                BackgroundWorker backgroundWorker = new BackgroundWorker(Facilitation_Feedback.this);

                                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(Facilitation_Feedback.this);
                                String ID = sharedPreferences.getString("ID", "unknown");

                                backgroundWorker.execute(type, Victims_Linked_To_Centres, Contacted_Centre_Location, Contacted_Centre_Category, Centre_Contacted, ID);


                            } else {
                                Toast.makeText(getApplicationContext(), getString(R.string.noNetConn), Toast.LENGTH_LONG).show();
                                return;
                            }


                        }
                    })
                    .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();

        }
    }

}
