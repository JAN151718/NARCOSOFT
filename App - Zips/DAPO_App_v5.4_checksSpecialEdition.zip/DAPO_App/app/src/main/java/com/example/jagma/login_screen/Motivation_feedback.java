package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;

public class Motivation_feedback extends AppCompatActivity {

    EditText d_m_a1;
    MultiSelectSpinner d_m_a2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motivation_feedback);

        d_m_a1 = findViewById(R.id.d_m_a1);
        d_m_a2 = findViewById(R.id.d_m_a2); // Declaration


        ArrayList<String> options4 = new ArrayList<>();
        options4.add(getString(R.string.m_a3_prb1));
        options4.add(getString(R.string.m_a3_prb2));
        options4.add(getString(R.string.m_a3_prb3));
        //options4.add(getString(R.string.any));

        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options4);

        d_m_a2.setListAdapter(adapter4)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText(getString(R.string.selAll))
                .setAllUncheckedText(getString(R.string.m_a3_prompt))
                .setSelectAll(false)
                .setTitle(getString(R.string.m_a3_prompt))
                .setMinSelectedItems(1); // Spinner 1



    }

    public void Proceed(View view) {
        if (d_m_a1 == null || d_m_a2.getSelectedItem().toString().equals(getString(R.string.m_a3_prompt))) {
            Toast.makeText(getApplicationContext(), "Fill at least one field", Toast.LENGTH_LONG).show();
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.dialog_proceed_head))
                    .setCancelable(false)
                    .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(Motivation_feedback.this,Submit_screen.class);
                        startActivityForResult(i,2);
                        finish();*/

                            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                            if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {

                                String Victims_Approached = d_m_a1.getText().toString();
                                String Victim_Approach_Problems = d_m_a2.getSelectedItem().toString();
                                ;

                                String type = "deaddiction motivation";
                                BackgroundWorker backgroundWorker = new BackgroundWorker(Motivation_feedback.this);

                                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(Motivation_feedback.this);
                                String ID = sharedPreferences.getString("ID", "unknown");

                                backgroundWorker.execute(type, Victims_Approached, Victim_Approach_Problems, ID);


                            } else {
                                Toast.makeText(getApplicationContext(), getString(R.string.noNetConn), Toast.LENGTH_LONG).show();
                                return;
                            }


                        }
                    })
                    .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();

        }
    }
}
