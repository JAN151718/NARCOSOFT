package com.example.jagma.login_screen;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Submit_screen extends AppCompatActivity{

    static String calling_activity;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_screen);
        calling_activity = getIntent().getStringExtra("calling-activity");

        Log.d("ADebugTag","Calling activity " + calling_activity);
    }

    public void MoreEntries(View v)
    {
        if (calling_activity.equals("act_awareness")) {
            Intent i = new Intent(this, Awareness_Activity.class);
            startActivity(i);
            finish();
        }
        else if(calling_activity.equals("act_vg_protection")){
            Intent i = new Intent(this, Protection.class);
            startActivity(i);
            finish();
        }
        else if(calling_activity.equals("act_vg_identification")){
            Intent i = new Intent(this, Protection.class);
            startActivity(i);
            finish();
        }
        else if(calling_activity.equals("act_deaddiction_followup")){
            Intent i = new Intent(this, Deaddiction.class);
            startActivity(i);
            finish();
        }
        else if(calling_activity.equals("act_deaddiction_facilitation")){
            Intent i = new Intent(this, Deaddiction.class);
            startActivity(i);
            finish();
        }
        else if(calling_activity.equals("act_deaddiction_motivation")){
            Intent i = new Intent(this, Deaddiction.class);
            startActivity(i);
            finish();
        }
        else if(calling_activity.equals("act_deaddiction_identification")){
            Intent i = new Intent(this, Deaddiction.class);
            startActivity(i);
            finish();
        }
        else if(calling_activity.equals("act_pos")){
            Intent i = new Intent(this, positive_activities.class);
            startActivity(i);
            finish();
        }
        else if(calling_activity.equals("act_vigilance")){
            Intent i = new Intent(this, Vigilance_and_Security.class);
            startActivity(i);
            finish();
        }
    }

    public void Finish(View v){
        Toast.makeText(getApplicationContext(),getString(R.string.thx_msg),Toast.LENGTH_LONG).show();
        Intent i=new  Intent(this,Main_task_page.class);
        startActivity(i);
        finish();
    }

}
