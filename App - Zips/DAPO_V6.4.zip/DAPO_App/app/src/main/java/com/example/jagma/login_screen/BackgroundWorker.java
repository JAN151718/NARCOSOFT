package com.example.jagma.login_screen;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.ProgressBar;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BackgroundWorker extends AsyncTask<String,Void,String> {

    Context context;
    AlertDialog alertDialog;
    BackgroundWorker (Context ctx){
        context = ctx;
    }
    String   paramm[];
    String UID;
    String type;

    static String activ;

    protected ProgressBar mProgressBar;
    private int progressBarStatus = 0;
    ProgressDialog progDialog;

    String motivation;

    @Override
    protected void onPreExecute() {
        progDialog = new ProgressDialog(context);
        progDialog.setMessage("Please wait.");
        progDialog.setCancelable(false);
        progDialog.setIndeterminate(true);
        progDialog.show();
        progressBarStatus = 0;
    }


    @Override
    protected String doInBackground(String... params) {
        paramm=params;
        type = params[0];
        String login_url = "http://115.112.58.50:8097/dapoapi/login.php";
        String deaddiction_identification_url = "http://115.112.58.50:8097/dapoapi/deaddiction_identification.php";
        String deaddiction_motivation_url = "http://115.112.58.50:8097/dapoapi/deaddiction_motivation.php";
        String deaddiction_facilitation_url = "http://115.112.58.50:8097/dapoapi/deaddiction_facilitation.php";
        String deaddiction_followup_url = "http://115.112.58.50:8097/dapoapi/deaddiction_followup.php";
        String vg_identification_url = "http://115.112.58.50:8097/dapoapi/Identification_VG.php";
        String vg_protection_url = "http://115.112.58.50:8097/dapoapi/Protection_VG.php";
        String awareness_url = "http://115.112.58.50:8097/dapoapi/Awareness.php";
        String positive_activity_url = "http://115.112.58.50:8097/dapoapi/positive_activity.php";
        String vigilance_security_url = "http://115.112.58.50:8097/dapoapi/vigilance.php";
        String summary_url = "http://115.112.58.50:8097/dapoapi/summary.php";

        String result="";

        if (type.equals("summary")) {

            UID = params[2];
            String month = params[1];

            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(summary_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(5);

                nameValuePairs.add(new BasicNameValuePair("UID", UID));
                nameValuePairs.add(new BasicNameValuePair("month", month));
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;
        }

        if (type.equals("login")) {
            UID = params[1];
            String mobno = params[2];
            String rand = params[3];


                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(login_url);
                HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
                HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

                try {
                    List<NameValuePair> nameValuePairs = new ArrayList<>(5);

                    nameValuePairs.add(new BasicNameValuePair("UID", UID));
                    nameValuePairs.add(new BasicNameValuePair("MobNo", mobno));
                    nameValuePairs.add(new BasicNameValuePair("rannd", rand));

                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpclient.execute(httppost);
                    String responseBody = EntityUtils.toString(response.getEntity());
                    result = responseBody.trim();
                    Utilities.LogDebug(result);
                } catch (ClientProtocolException e) {
                    Utilities.LogDebug("error " + e.getMessage());
                } catch (IOException e) {
                    Utilities.LogDebug("error " + e.getMessage());
                }
                return result;
        }




        else if(type.equals("deaddiction identification"))
        {
            String Users = params[1];
            String Narcotics_Type = params[2];
            String Suspect_Name1 = params[3];
            String Suspect_Address1= params[4];
            String Suspect_Name2 = params[5];
            String Suspect_Address2= params[6];
            String Suspect_Name3 = params[7];
            String Suspect_Address3= params[8];

            String ID = params[9];

            activ = "act_deaddiction_identification";


            if(Narcotics_Type.equals("- Choose Drug(s) -"))
            {
                Narcotics_Type = "";
            }

            else if(Narcotics_Type.equals("All Selected"))
            {
                Narcotics_Type = "Heroin(Chitta);Smack; Opium (Afeem);Poppy Husk (Bhukki/Doda);Marijuana (Ganja);Capsules / Tablets / Syrup (Medical Nasha)";
            }


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(deaddiction_identification_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Number_of_Narcotics_Users", Users));
                nameValuePairs.add(new BasicNameValuePair("Type_of_Drugs_Used", Narcotics_Type));
                nameValuePairs.add(new BasicNameValuePair("Name_of_Suspect_1",Suspect_Name1));
                nameValuePairs.add(new BasicNameValuePair("Address_of_Suspect_1",Suspect_Address1));
                nameValuePairs.add(new BasicNameValuePair("Name_of_Suspect_2",Suspect_Name2));
                nameValuePairs.add(new BasicNameValuePair("Address_of_Suspect_2",Suspect_Address2));
                nameValuePairs.add(new BasicNameValuePair("Name_of_Suspect_3",Suspect_Name3));
                nameValuePairs.add(new BasicNameValuePair("Address_of_Suspect_3",Suspect_Address3));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }

        else if(type.equals("deaddiction motivation"))
        {
            String Victims_Approached = params[1];
            String Motivation_Problems = params[2];

            String ID = params[3];

            activ = "act_deaddiction_motivation";

            if(Motivation_Problems.equals("- Specify Problem(s) -"))
            {
                Motivation_Problems = "";
            }
            else if(Motivation_Problems.equals("All Selected"))
            {
                Motivation_Problems = "Refusal;Hostility;Fear of social stigma";
            }


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(deaddiction_motivation_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Number_of_Victims_Approached_Monthly", Victims_Approached));
                nameValuePairs.add(new BasicNameValuePair("Problems_Regarding_Motivation", Motivation_Problems));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }

        else if(type.equals("deaddiction facilitation"))
        {
            String Victims_Sent = params[1];
            String Centre_Location =  params[2];
            String Centre_Category =  params[3];
            String Centre_Contacted =  params[4];

            activ = "act_deaddiction_facilitation";

            String ID = params[5];

            if(Centre_Location.equals("- Choose Location -"))
            {
                Centre_Location = "";
            }
            if(Centre_Category.equals("- Choose Category -"))
            {
                Centre_Category = "";
            }

            if(Centre_Contacted.equals("- Choose Centre -"))
            {
                Centre_Contacted = "";
            }


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(deaddiction_facilitation_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Number_of_Approached_Victims_Linked_to_an_OOAT_Centre", Victims_Sent));
                nameValuePairs.add(new BasicNameValuePair("Contacted_Centre_Location", Centre_Location));
                nameValuePairs.add(new BasicNameValuePair("Contacted_Centre_Category", Centre_Category));
                nameValuePairs.add(new BasicNameValuePair("Centre_Contacted", Centre_Contacted));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }

        else if(type.equals("deaddiction followup"))
        {
            String Drop_outs = params[1];
            String Drop_out_reason = params[2];
            String Victim_problems = params[3];
            String ID = params[4];

            activ = "act_deaddiction_followup";

            if(Drop_out_reason.equals("- Specify Reason(s) -"))
            {
                Drop_out_reason = "";
            }
            else if(Drop_out_reason.equals("All Selected"))
            {
                Drop_out_reason = "Daily earnings being affected;Drugs easily available to victims;Lack of family support;Lack of counseling at the centre;Continuous peer pressure";
            }

            if(Victim_problems.equals("- Specify Problem(s) -"))
            {
                Victim_problems = "";
            }
            else if(Victim_problems.equals("All Selected"))
            {
                Victim_problems = "";
            }


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(deaddiction_followup_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Number_of_Drop_Outs_From_Treatment", Drop_outs));
                nameValuePairs.add(new BasicNameValuePair("Reason_For_Dropping_Out", Drop_out_reason));
                nameValuePairs.add(new BasicNameValuePair("Victims_Problems",Victim_problems));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }

        else if(type.equals("vg identification"))
        {
            String Vulnerable_Identified = params[1];
            String Vulnerable_Counseled = params[2];

            String ID = params[3];

            activ = "act_vg_identification";


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(vg_identification_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Number_of_Vulnerable_Individuals_or_Groups_Identified", Vulnerable_Identified));
                nameValuePairs.add(new BasicNameValuePair("Number_of_Vulnerable_Individuals_or_Groups_Counseled", Vulnerable_Counseled));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;


        }

        else if(type.equals("vg protection"))
        {
            String Efforts_For_Protection = params[1];
            String ID = params[2];

            activ = "act_vg_protection";

            if(Efforts_For_Protection.equals("- Specify Effort(s) -"))
            {
                Efforts_For_Protection = "";
            }
            else if(Efforts_For_Protection.equals("All Selected"))
            {
                Efforts_For_Protection = "Counseled the vulnerable regarding ill effects of drugs;Organised Sports events;Organised Cultural events;Promoted Social work;Organised Spiritual activities;Gave out pamphlets, films in order to spread awareness";
            }


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(vg_protection_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Efforts_Made_for_Protection_of_Vulnerable_Groups", Efforts_For_Protection));

                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

         }

        else if(type.equals("awareness"))
        {
            String Awareness_Activity = params[1];
            String ID = params[2];
            String fname1 = params[3];

            activ = "act_awareness";

            if(Awareness_Activity.equals("- Choose Activity -"))
            {
                Awareness_Activity = "";
            }
            else if(Awareness_Activity.equals("All Selected"))
            {
                Awareness_Activity = "Showed a short film;Performed a Nukkad Natak;Distributed printed material;Addressed a sath/local gathering;Spoke at a festival";
            }



            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(awareness_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Awareness_Activity_Completion", Awareness_Activity));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));
                nameValuePairs.add(new BasicNameValuePair("filename", fname1));


                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;


        }

        else if(type.equals("positive activity"))
        {

            String Positive_Activity = params[1];
            String Activity_Venue = params[2];
            String Problems = params[3];
            String ID = params[4];
            String fname1 = params[5];

            activ = "act_pos";

            if(Positive_Activity.equals("- Choose Activity -"))
            {
                Positive_Activity = "";
            }
            else if(Positive_Activity.equals("All Selected"))
            {
                Positive_Activity = "Sports;Cultural;Social Service;Group Discussion";
            }

            if(Activity_Venue.equals("- Specify Location -"))
            {
                Activity_Venue = "";
            }
            else if(Activity_Venue.equals("All Selected"))
            {
                Activity_Venue = "Local stadium;School playground;Village chaupal;Mela ground;Community hall";
            }

            if(Problems.equals("- Specify Problem -"))
            {
                Problems = "";
            }
            else if(Problems.equals("All Selected"))
            {
                Problems = "Lack of infrastructure (public grounds, furniture, equipment etc.);Lack of funds for organising activities;Absence of an official to aid the activity organisation;Scarce participation of people in these activities";
            }


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(positive_activity_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Positive_Activity_Performed", Positive_Activity));
                nameValuePairs.add(new BasicNameValuePair("Activity_Venue", Activity_Venue));
                nameValuePairs.add(new BasicNameValuePair("Problem", Problems));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));
                nameValuePairs.add(new BasicNameValuePair("filename", fname1));


                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }

        else if(type.equals("vigilance"))
        {
            activ = "act_vigilance";
            String Vigilance_and_Security_Activity = params[1];
            String Number_Of_Activities = params[2];
            String ID = params[3];
            String fname1 = params[4];

            if(Vigilance_and_Security_Activity.equals("- Choose Activity -"))
            {
                Vigilance_and_Security_Activity = "";
            }
            else if(Vigilance_and_Security_Activity.equals("All Selected"))
            {
                Vigilance_and_Security_Activity = "Identification of outsiders / suspicious persons entering the locality;Informing the authorities about any shady activity;Organising Watch and Ward groups (Thikri pehrah, Village defence team)";
            }


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(vigilance_security_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Vigilance_and_Security_Activity", Vigilance_and_Security_Activity));
                nameValuePairs.add(new BasicNameValuePair("Number_Of_Activities_Performed", Number_Of_Activities));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));
                nameValuePairs.add(new BasicNameValuePair("filename", fname1));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }


        return null;


    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);

    }

    @Override
    protected void onPostExecute(String result) {
        if (progDialog != null) {

            progDialog.dismiss();
            if (result.equals("Login Successful")) {

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);

                alertDialog.setCancelable(false);

                alertDialog.setMessage(context.getString(R.string.msg_otp));

                alertDialog.setPositiveButton(context.getString(R.string.ok), new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(context);
                        String id=UID;

                        sharedPreferences.edit().putString("ID", id).commit();

                        context.startActivity(new Intent(context, otp_page.class));
                        //((Activity) context).finish();

                    }
                });
                AlertDialog dialog = alertDialog.create();
                dialog.show();


            }

            else if (result.equals("Submission Successful")) {
                /*
                context.startActivity(new Intent(context, Submit_screen.class));
                ((Activity) context).finish();
                */
                String className = this.getClass().getSimpleName();
                Log.d("ADebugTag","Current Class" + className);
                Log.d("ADebugTag","activity" + activ);

                Intent submitScreen = new Intent(context, Submit_screen.class);
                submitScreen.putExtra("calling-activity",activ);
                context.startActivity(submitScreen);

            }

            else if (type.equals("summary")) {

                if (result != null && !result.equals("{}")) {
                    try {
                        System.out.println(result);
                        JSONObject jsonObj = new JSONObject(result);
                        JSONArray jsondistrictarray = jsonObj.getJSONArray("Motivation");
                        for (int i = 0; i < jsondistrictarray.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray.getJSONObject(i);
                           motivation=jsonObjdistrict.getString("Motivation");
                        }

                       // str_chk = "Success";
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            else {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
                alertDialog.setCancelable(false);
                alertDialog.setMessage(result);
                alertDialog.setPositiveButton(context.getString(R.string.ok), new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       // clue.requestFocus();
                    }
                });
                AlertDialog dialog = alertDialog.create();
                dialog.show();
            }
        }
    }


}