package com.example.jagma.login_screen;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class mohalla_status extends AppCompatActivity {

    //private static String TAG ="MainActivity";

    //HARD CODED VALUES TO BE CHANGED AS PER DATABASE

    public int      total_people = 200,
                    healthy = 100,
                    rehab = 250,
                    active_users = 75,
                    vulnerable = 70,
                    unknown = 100;

    TextView        total_ans;
    TextView        healthy_ans;
    TextView        treatment_ans;
    TextView        vul_ans;
    TextView        users_ans;
    TextView        unknown_ans;
    TextView        location_subhead;

    String location = "<Location>";



    //PERCENTAGE CALCULATION FOR DISPLAY

    public float hea_mod = ((float)healthy*100)/(float)total_people;
    public float rehab_mod = ((float)rehab*100)/(float)total_people;
    public float vul_mod = ((float)vulnerable*100)/(float)total_people;
    public float active_mod = ((float)active_users*100)/(float)total_people;
    public float unknown_mod = ((float)unknown*100)/(float)total_people;

    private float[] ydata;

    /*
    private String[] xdata={
            getString(R.string.xdata_1),
            getString(R.string.xdata_2),
            getString(R.string.xdata_3),
            getString(R.string.xdata_4),
            getString(R.string.xdata_5)
    };
    */

    private String[] xdata={
            "Healthy",
            "Rehabilitating",
            "Vulnerable",
            "Drug Abusing",
            "Unknown"
    };

    //GLOBAL pieChart
    PieChart pieChart;

    Context context;
    String ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mohalla_status);

        pieChart = (PieChart) findViewById(R.id.pie);


        context=this;
        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(mohalla_status.this);
        ID =sharedPreferences.getString("ID","unknown");
        //------------------------------------------------------------------------------------------
        //SETTING VALUES FOR FIELDS

     /* total_ans = findViewById(R.id.total_ans);
        healthy_ans = findViewById(R.id.healthy_ans);
        treatment_ans = findViewById(R.id.treatment_ans);
        vul_ans = findViewById(R.id.vul_ans);
        users_ans = findViewById(R.id.users_ans);
        unknown_ans = findViewById(R.id.unknown_ans);
        location_subhead = findViewById(R.id.location_subhead);

        total_ans.setText(getString(total_people));
        healthy_ans.setText(getString(healthy));
        treatment_ans.setText(getString(rehab));
        users_ans.setText(getString(active_users));
        vul_ans.setText(getString(vulnerable));
        unknown_ans.setText(getString(unknown));

        location_subhead.setText(location);*/

        //------------------------------------------------------------------------------------------


        //DESCRIPTION
        Description descrip = new Description();
        descrip.setText("");
        descrip.setTextSize(15f);
        pieChart.setDescription(descrip);
        pieChart.getDescription().setEnabled(false);


        //------------------------------------------------------------------------------------------

        //PIECHART PROPERTIES

        pieChart.setRotationEnabled(true);
        pieChart.setHoleRadius(50f);
        pieChart.setTransparentCircleAlpha(0);
        pieChart.setCenterText(getString(R.string.pie_center_msg));
        pieChart.setCenterTextSize(25f);
        pieChart.spin( 1400,-360f,0f, Easing.EasingOption.EaseInOutQuad);
        //pieChart.animate();

        AsyncTaskRunner runner = new AsyncTaskRunner();
        String sleepTime = "10";
        runner.execute(sleepTime);

    }








    private class AsyncTaskRunner extends AsyncTask<String, String, String> {

        private String resp;
        ProgressDialog progDialog;
        protected ProgressBar mProgressBar;
        private int progressBarStatus = 0;
        String result="";


        @Override
        protected void onPreExecute() {
            progDialog = new ProgressDialog(context);
            progDialog.setMessage("Please wait.");
            progDialog.setCancelable(false);
            progDialog.setIndeterminate(true);
            progDialog.show();
            progressBarStatus = 0;
        }


        @Override
        protected String doInBackground(String... params) {
            String summary_url = "http://115.112.58.50:8097/dapoapi/summary2.php";


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(summary_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(5);

                nameValuePairs.add(new BasicNameValuePair("UID", ID));
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;
        }


        @Override
        protected void onPostExecute(String result) {

            if (progDialog != null) {
                progDialog.dismiss();
                // execution of result of Long time consuming operation



                if (result != null && !result.equals("{}")) {
                    try {
                        System.out.println(result);
                        JSONObject jsonObj = new JSONObject(result);


                        JSONArray jsondistrictarray2 = jsonObj.getJSONArray("Mohalla");

                            JSONObject jsonObjdistrict = jsondistrictarray2.getJSONObject(0);

                        float rehab_get=Float.parseFloat(jsonObjdistrict.getString("Rehabilitating"));
                        float vulnerable_get=Float.parseFloat(jsonObjdistrict.getString("Vulnerable"));
                        float active_users_get=Float.parseFloat(jsonObjdistrict.getString("Drugabusing"));

                        total_people=total_people+(int) rehab_get+(int) vulnerable_get+(int) active_users_get;

                         hea_mod = ((float)healthy*100)/(float)total_people;
                         rehab_mod = ((float)rehab_get*100)/(float)total_people;
                         vul_mod = ((float)vulnerable_get*100)/(float)total_people;
                         active_mod = ((float)active_users_get*100)/(float)total_people;
                         unknown_mod = ((float)unknown*100)/(float)total_people;

                       ydata = new float[]{hea_mod, rehab_mod, vul_mod, active_mod, unknown_mod};


                        total_ans = findViewById(R.id.total_ans);
                        healthy_ans = findViewById(R.id.healthy_ans);
                        treatment_ans = findViewById(R.id.treatment_ans);
                        vul_ans = findViewById(R.id.vul_ans);
                        users_ans = findViewById(R.id.users_ans);
                        unknown_ans = findViewById(R.id.unknown_ans);
                        location_subhead = findViewById(R.id.location_subhead);

                        total_ans.setText(String.valueOf(total_people));
                        healthy_ans.setText(String.valueOf(healthy));
                        treatment_ans.setText(String.valueOf(rehab_get));
                        users_ans.setText(String.valueOf(active_users_get));
                        vul_ans.setText(String.valueOf(vulnerable_get));
                        unknown_ans.setText(String.valueOf(unknown));


                        addDataSet();

                        // str_chk = "Success";
                    } catch (Exception e) {
                        System.out.println("Error :"+e.getMessage());
                    }
                }


            }
        }

    }






    private void addDataSet() {
        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();

        for(int i=0;i<ydata.length;i++){
            yEntrys.add(new PieEntry(ydata[i],i));
        }

        for(int i=0;i<xdata.length;i++){
            xEntrys.add(xdata[i]);
        }

        PieDataSet set1 = new PieDataSet(yEntrys,getString(R.string.pie_bottom_label));
        set1.setSliceSpace(2);
        set1.setValueTextSize(10);

        ArrayList<Integer> colors = new ArrayList<>();
        //green-healthy
        colors.add(Color.rgb(177,242,0));
        //yellow-rehab
        colors.add(Color.rgb(255,222,32));
        //orange-vul
        colors.add(Color.rgb(255,157,0));
        //red-drugUsers
        colors.add(Color.rgb(255,165,165));
        //grey-unknown
        colors.add(Color.rgb(211,211,211));

        set1.setColors(colors);

        /*
        //LEGEND
        Legend legend = pieChart.getLegend();
        legend.setEnabled(false);
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.getEntries();
        */

        //object
        PieData pieData = new PieData(set1);
        pieChart.setData(pieData);
        pieData.setValueTextSize(18f);
        set1.setYValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        //pieData.setValueTextColor(Color.WHITE);

        //pieChart.animate(1400,1400);

        pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                //DEBUG
                //Log.d(TAG,"OnValueSelected: value selected ");
                //Log.d(TAG,"OnValueSelcted: "+ e.toString());
                //Log.d(TAG,"OnValueSelcted: "+ h.toString());
                //Log.d(TAG,"OnValueSelcted: ");

                // FOR SELECTED DISPLAY
                //int pos1=(int)(e.getY()*total_people)/100;
                //int stat=(int)h.getX();
                //Toast.makeText(mohalla_status.this, getString(R.string.pie_msg_start) + pos1 +" "+ xdata[stat] + getString(R.string.pie_msg_end) ,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected() {
            }
        });
    }
}
