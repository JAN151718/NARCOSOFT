package com.example.jagma.login_screen;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class summary extends AppCompatActivity {

    Context context;
    Spinner date_dd;
    Spinner year_dd;

    TextView d_m_a1, d_i_a1,d_i_a2,d_i_a3 ,d_f_a1,d_f_a2, d_fu_a1,d_fu_a2, p_i_a1,p_i_a2, p_p_a1, a_a1, pa_a1,pa_a2,pa_a3, vs_a1,vs_a2;


    String motivation;
    String month,ID,year;
    String type="summary";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        date_dd=findViewById(R.id.date_dd);
        year_dd=findViewById(R.id.year_dd);
        context=this;

        d_m_a1=findViewById(R.id.d_m_a1);

        d_i_a1=findViewById(R.id.d_i_a1);
        d_i_a2=findViewById(R.id.d_i_a2);
        d_i_a3=findViewById(R.id.d_i_a3);

        d_f_a1=findViewById(R.id.d_f_a1);
        d_f_a2=findViewById(R.id.d_f_a2);

        d_fu_a1=findViewById(R.id.d_fu_a1);
        d_fu_a2=findViewById(R.id.d_fu_a2);

        p_i_a1=findViewById(R.id.p_i_a1);
        p_i_a2=findViewById(R.id.p_i_a2);

        p_p_a1=findViewById(R.id.p_p_a1);

        a_a1=findViewById(R.id.a_a1);

        pa_a1=findViewById(R.id.pa_a1);
        pa_a2=findViewById(R.id.pa_a2);
        pa_a3=findViewById(R.id.pa_a3);

        vs_a1=findViewById(R.id.vs_a1);
        vs_a2=findViewById(R.id.vs_a2);



        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(summary.this);
        ID =sharedPreferences.getString("ID","unknown");



        date_dd.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                month=date_dd.getSelectedItem().toString();
                AsyncTaskRunner runner = new AsyncTaskRunner();
                String sleepTime = "10";
                runner.execute(sleepTime);


        }


            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });


        year_dd.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                year=year_dd.getSelectedItem().toString();
                AsyncTaskRunner runner = new AsyncTaskRunner();
                String sleepTime = "10";
                runner.execute(sleepTime);


            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });


    }


    private class AsyncTaskRunner extends AsyncTask<String, String, String> {

        private String resp;
        ProgressDialog progDialog;
        protected ProgressBar mProgressBar;
        private int progressBarStatus = 0;
        String result="";


        @Override
        protected void onPreExecute() {
            progDialog = new ProgressDialog(context);
            progDialog.setMessage("Please wait.");
            progDialog.setCancelable(false);
            progDialog.setIndeterminate(true);
            progDialog.show();
            progressBarStatus = 0;
        }


        @Override
        protected String doInBackground(String... params) {

            System.out.println("Position: "+date_dd.getSelectedItemPosition());

            if(date_dd.getSelectedItemPosition()==1){month="January";}
            if(date_dd.getSelectedItemPosition()==2){month="February";}
            if(date_dd.getSelectedItemPosition()==3){month="March";}
            if(date_dd.getSelectedItemPosition()==4){month="April";}
            if(date_dd.getSelectedItemPosition()==5){month="May";}
            if(date_dd.getSelectedItemPosition()==6){month="June";}
            if(date_dd.getSelectedItemPosition()==7){month="July";}
            if(date_dd.getSelectedItemPosition()==8){month="August";}
            if(date_dd.getSelectedItemPosition()==9){month="September";}
            if(date_dd.getSelectedItemPosition()==10){month="October";}
            if(date_dd.getSelectedItemPosition()==11){month="November";}
            if(date_dd.getSelectedItemPosition()==12){month="December";}

            if(date_dd.getSelectedItemPosition()!=0 && year_dd.getSelectedItemPosition()!=0) {
                String summary_url = "http://115.112.58.50:8097/dapoapi/summary.php";

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(summary_url);
                HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
                HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

                try {
                    List<NameValuePair> nameValuePairs = new ArrayList<>(5);

                    nameValuePairs.add(new BasicNameValuePair("UID", ID));
                    nameValuePairs.add(new BasicNameValuePair("month", month));
                    nameValuePairs.add(new BasicNameValuePair("year", year));
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    HttpResponse response = httpclient.execute(httppost);
                    String responseBody = EntityUtils.toString(response.getEntity());
                    result = responseBody.trim();
                    Utilities.LogDebug(result);
                } catch (ClientProtocolException e) {
                    Utilities.LogDebug("error " + e.getMessage());
                } catch (IOException e) {
                    Utilities.LogDebug("error " + e.getMessage());
                }
                return result;
            }
            else {
                return result;
            }
        }

        /*protected  String SplitString(String temp)
        {


            return temp;
        }*/
        @Override
        protected void onPostExecute(String result) {

            if (progDialog != null) {
                progDialog.dismiss();
                // execution of result of Long time consuming operation



                if (result != null && !result.equals("{}")) {
                    try {
                        System.out.println(result);
                        JSONObject jsonObj = new JSONObject(result);

                        JSONArray jsondistrictarray2 = jsonObj.getJSONArray("Identification");
                        for (int i = 0; i < jsondistrictarray2.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray2.getJSONObject(i);

                            d_i_a1.setText(jsonObjdistrict.getString("Number_of_Narcotics_Users"));

                            //................................................................................

                            String  temp = jsonObjdistrict.getString("Type_of_Drugs_Used");

                            //  Removing Repeating Values
                            temp = temp.replaceAll("\\,\\s",",");
                            //String[] items = temp.split("[,;]");
                            ArrayList <String> item_list = new ArrayList<String>(Arrays.asList(temp.split("[,;]")));
                            item_list.remove(0);
                            String [] items = new LinkedHashSet<String>(item_list).toArray(new String[0]);
                            String ident_data = "";

                            for(String x: items)
                                ident_data += "- " + x + "\n";

                            d_i_a2.setText(ident_data);

                            //................................................................................

                            d_i_a3.setText(jsonObjdistrict.getString("Num_of_Suspect"));

                        }

                        JSONArray jsondistrictarray = jsonObj.getJSONArray("Motivation");
                        for (int i = 0; i < jsondistrictarray.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray.getJSONObject(i);
                            motivation = jsonObjdistrict.getString("Motivation");

                        }
                        d_m_a1.setText(motivation);



                        JSONArray jsondistrictarray3 = jsonObj.getJSONArray("Facilitating");
                        for (int i = 0; i < jsondistrictarray3.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray3.getJSONObject(i);

                            d_f_a1.setText(jsonObjdistrict.getString("Number_of_Approached_Victims"));

                            //d_f_a2.setText(jsonObjdistrict.getString("Centre_Contacted"));
                            String  temp = jsonObjdistrict.getString("Centre_Contacted");

                            //  Removing Repeating Values
                            temp = temp.replaceAll("\\,\\s",",");
                            //String[] items = temp.split("[,;]");
                            ArrayList <String> item_list = new ArrayList<String>(Arrays.asList(temp.split("[,;]")));
                            item_list.remove(0);
                            String [] items = new LinkedHashSet<String>(item_list).toArray(new String[0]);

                            items = new LinkedHashSet<String>(Arrays.asList(items)).toArray(new String[0]);
                            String fac_data = "";

                            for(String x: items)
                                fac_data += "- " + x + "\n";

                            d_f_a2.setText(fac_data);
                        }

                        JSONArray jsondistrictarray4 = jsonObj.getJSONArray("Followup");
                        for (int i = 0; i < jsondistrictarray4.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray4.getJSONObject(i);

                            d_fu_a1.setText(jsonObjdistrict.getString("Drop_Outs_From_Treatment"));

                            //..................................................................................

                            String temp = jsonObjdistrict.getString("Reason_For_Dropping_Out");
                                //  Removing Repeating Values
                                temp = temp.replaceAll("\\,\\s",",");
                                //String[] items = temp.split("[,;]");
                                ArrayList <String> item_list = new ArrayList<String>(Arrays.asList(temp.split("[,;]")));
                                item_list.remove(0);
                                String [] items = new LinkedHashSet<String>(item_list).toArray(new String[0]);

                                items = new LinkedHashSet<String>(Arrays.asList(items)).toArray(new String[0]);
                                String follow_up_data = "";

                                for(String x: items)
                                    follow_up_data += "- " + x + "\n";


                            d_fu_a2.setText(follow_up_data );

                        }

                        JSONArray jsondistrictarray5 = jsonObj.getJSONArray("VulnerableIden");
                        for (int i = 0; i < jsondistrictarray5.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray5.getJSONObject(i);
                            p_i_a1.setText(jsonObjdistrict.getString("Groups_Identified"));
                            p_i_a2.setText(jsonObjdistrict.getString("Groups_Counseled"));
                        }

                        JSONArray jsondistrictarray6 = jsonObj.getJSONArray("VulnerableProt");
                        for (int i = 0; i < jsondistrictarray6.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray6.getJSONObject(i);

                            //................................................................................


                            String  temp = jsonObjdistrict.getString("Protection_of_Vulnerable_Groups");
                                //  Removing Repeating Values
                                temp = temp.replaceAll("\\,\\s",",");
                                //String[] items = temp.split("[,;]");
                                ArrayList <String> item_list = new ArrayList<String>(Arrays.asList(temp.split("[,;]")));
                                item_list.remove(0);
                                String [] items = new LinkedHashSet<String>(item_list).toArray(new String[0]);

                                items = new LinkedHashSet<String>(Arrays.asList(items)).toArray(new String[0]);
                                String prot_data = "";

                                for(String x: items)
                                    prot_data += "- " + x + "\n";

                            p_p_a1.setText(prot_data);

                        }

                        JSONArray jsondistrictarray7 = jsonObj.getJSONArray("Awareness");
                        for (int i = 0; i < jsondistrictarray7.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray7.getJSONObject(i);

                            //..............................................................................

                            String  temp = jsonObjdistrict.getString("Awareness_Activity_Completion");
                                //  Removing Repeating Values
                                temp = temp.replaceAll("\\,\\s",",");
                                //String[] items = temp.split("[,;]");
                                ArrayList <String> item_list = new ArrayList<String>(Arrays.asList(temp.split("[,;]")));
                                item_list.remove(0);
                                String [] items = new LinkedHashSet<String>(item_list).toArray(new String[0]);

                                items = new LinkedHashSet<String>(Arrays.asList(items)).toArray(new String[0]);
                                String aw_data = "";

                                for(String x: items)
                                    aw_data += "- " + x + "\n";

                            a_a1.setText(aw_data);


                        }

                        JSONArray jsondistrictarray8 = jsonObj.getJSONArray("Positive");
                        for (int i = 0; i < jsondistrictarray8.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray8.getJSONObject(i);

                            //............................................................................

                            String  temp = jsonObjdistrict.getString("Positive_Activity_Performed");
                                //  Removing Repeating Values
                                temp = temp.replaceAll("\\,\\s",",");
                                //String[] items = temp.split("[,;]");
                                ArrayList <String> item_list = new ArrayList<String>(Arrays.asList(temp.split("[,;]")));
                                item_list.remove(0);
                                String [] items = new LinkedHashSet<String>(item_list).toArray(new String[0]);

                                items = new LinkedHashSet<String>(Arrays.asList(items)).toArray(new String[0]);
                                String pa_data_1 = "";

                                for(String x: items)
                                    pa_data_1 += "- " + x + "\n";

                            pa_a1.setText(pa_data_1);

                            //......................................................................

                            temp = jsonObjdistrict.getString("Activity_Venue");
                                    //  Removing Repeating Values
                                    temp = temp.replaceAll("\\,\\s",",");
                                //String[] items = temp.split("[,;]");
                                item_list = new ArrayList<String>(Arrays.asList(temp.split("[,;]")));
                                item_list.remove(0);
                                items = new LinkedHashSet<String>(item_list).toArray(new String[0]);

                                    items = new LinkedHashSet<String>(Arrays.asList(items)).toArray(new String[0]);
                                    String pa_data_2 = "";

                                    for(String x: items)
                                        pa_data_2 += "- " + x + "\n";

                            pa_a2.setText(pa_data_2);

                            //......................................................................

                            temp = jsonObjdistrict.getString("Problem");
                                //  Removing Repeating Values
                                temp = temp.replaceAll("\\,\\s",",");
                                //String[] items = temp.split("[,;]");
                                item_list = new ArrayList<String>(Arrays.asList(temp.split("[,;]")));
                                item_list.remove(0);
                                items = new LinkedHashSet<String>(item_list).toArray(new String[0]);

                                items = new LinkedHashSet<String>(Arrays.asList(items)).toArray(new String[0]);
                                String pa_data_3 = "";

                                for(String x: items)
                                    pa_data_3 += "- " + x + "\n";

                            pa_a3.setText(pa_data_3);

                        }

                        JSONArray jsondistrictarray9 = jsonObj.getJSONArray("Vigilance");
                        for (int i = 0; i < jsondistrictarray9.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray9.getJSONObject(i);
                            vs_a2.setText(jsonObjdistrict.getString("Number_Of_Activities_Performed"));

                            //................................................................................

                            String  temp = jsonObjdistrict.getString("Vigilance_and_Security_Activity");
                                //  Removing Repeating Values
                                temp = temp.replaceAll("\\,\\s",",");
                                //String[] items = temp.split("[,;]");
                                ArrayList <String> item_list = new ArrayList<String>(Arrays.asList(temp.split("[,;]")));
                                item_list.remove(0);
                                String [] items = new LinkedHashSet<String>(item_list).toArray(new String[0]);

                                items = new LinkedHashSet<String>(Arrays.asList(items)).toArray(new String[0]);
                                String vs_data = "";

                                for(String x: items)
                                    vs_data += "- " + x + "\n";

                            vs_a1.setText(vs_data);



                        }









                        // str_chk = "Success";
                    } catch (Exception e) {
                     //   e.printStackTrace();
                    }
                }


            }
        }

    }


}
